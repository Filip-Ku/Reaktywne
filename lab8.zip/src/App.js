import './App.css';
import QuizComponent from "./components/QuizComponent";

function App() {
    return (
            <QuizComponent/>
    );
}

export default App;
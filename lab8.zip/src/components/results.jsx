import React from 'react';

const Results = (props) => {
    return (
        <p>{props.points} points</p>

    )
};

export default Results;
